module.exports = {
    plugins: [
      require('tailwindcss'),
      require('autoprefixer'),
      // You can add more PostCSS plugins here if needed
    ]
  }
  